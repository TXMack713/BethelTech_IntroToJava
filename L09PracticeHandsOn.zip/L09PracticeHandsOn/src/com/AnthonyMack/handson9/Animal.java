package com.AnthonyMack.handson9;

public class Animal {
	// mandatory variables
	private String name;
	private float length;
	private float height;
	private float weight;
	
	// optional variable
	private boolean isGrassFed;
	
	protected Animal(AnimalBuilder builder) {
		this.name = builder.name;
		this.length = builder.length;
		this.height = builder.height;
		this.weight = builder.weight;
		this.isGrassFed = builder.isGrassFed;
	}
	
	// define getters
	public String getName() {
		return name;
	}
	public float getLength() {
		return length;
	}
	public float getHeight() {
		return height;
	}
	public float getWeight() {
		return weight;
	}
	public boolean getIsGrassFed() {
		return isGrassFed;
	}
	
	public static class AnimalBuilder {
		// mandatory variables
		private String name;
		private float length;
		private float height;
		private float weight;
		
		// optional variable
		private boolean isGrassFed;
		
		public AnimalBuilder(String name, float length, float height, float weight) {
			this.name = name;
			this.length = length;
			this.height = height;
			this.weight = weight;
			
			// optional variable
			this.isGrassFed = false;
		}
		
		public AnimalBuilder setIsGrassFed(boolean isGrassFed) {
			this.isGrassFed = isGrassFed;
			return this;
		}
		
		// last method in `AnimalBuilder` class
		public Animal build() {
			return new Animal(this);
		}
	}
	

}
