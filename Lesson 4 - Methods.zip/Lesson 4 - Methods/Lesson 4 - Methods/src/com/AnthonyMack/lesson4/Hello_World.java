package com.AnthonyMack.lesson4;

public class Hello_World {

	public static void main(String[] args) {
		// Example #1 - Defining methods with parameters
		
		// String userName = "Lisa";
		// greetUser(userName);
//		greetUser("Lisa");
//		greetUser("Maya");
//		greetUser("Ava");
//		greetUser("Caleb");
//		greetUser("Josie");
		
		// Example #2 - Method Data Types
//		System.out.println(isEven(0));
//		System.out.println(isEven(1));
//		System.out.println(isEven(2));
//		System.out.println(isEven(3));
		
		// Example #3 - Passing in two integer variables
		// invoke the sum method while passing it two integers
		sum(13, 16.5);
	}
	
	public static void greetUser(String name) {
		System.out.println("Hello " + name + ", welcome to my program!");
	}
	public static boolean isEven(int number) {
		boolean result;
		
		// if the number is even, set the variable to true
		if (number % 2 == 0) {
			result = true;
		}
		// otherwise, set variable to false
		else {
			result = false;
		}
		// return the variable
		return result;
	}
	public static void sum(double num1, double num2) {
		System.out.println(num1 + num2);
	}

}
