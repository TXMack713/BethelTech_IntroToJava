package com.AnthonyMack.lesson2;

public class Lesson_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		// Else-if exercise
//		// Declare the variables needed for the exercise
//		int rating = 5;
//		
//		/* if the user rates the restaurant 5-stars, print "This food is the best!, I could eat this every day."
//		 * if the user rates the restaurant 4-stars, print "Good meal."
//		 * if the user rates the restaurant 3-stars, print "It was OK."
//		 * if the user rates the restaurant 2-stars, print "I did not like this, but it's cheap"
//		 * if the user rates the restaurant 1-star, print "I'd rather eat dirt."
//		 */
//		
//		if (rating == 5) {
//			System.out.println("This food is the best! I could eat this every day!");
//		}
//		else if (rating == 4) {
//			System.out.println("Good meal.");
//		}
//		else if (rating == 3) {
//			System.out.println("It was OK");
//		}
//		else if (rating == 2) {
//			System.out.println("I did not like this, but it was cheap.");
//		}
//		else {
//			System.out.println("I'd rather eat dirt.");
//		}
		
//		// Inequality operator exercise
//		int frankAge = 30;
//		int kevinAge = 40;
//		System.out.println(frankAge != kevinAge);
//		
//		int secondsPerMinute = 60;
//		int minutesPerHour = 60;
//		System.out.println(secondsPerMinute != minutesPerHour);
		
//		// And operator exercise
//		boolean isHungry = true;
//		boolean isRestaurantOpen = true;
//		
//		if (isHungry && isRestaurantOpen) {
//			System.out.println("Go to the restaurant!");
//		}
//		else {
//			System.out.println("Don't go to the restaurant.");
//		}
//		
//		boolean isSleepy = false;
//		boolean isLibraryClosed = false;
//		boolean isBatteryDead = false;
//		
//		if (isSleepy || isLibraryClosed || isBatteryDead) {
//			System.out.println("You should leave now.");
//		}
//		else {
//			System.out.println("Keep on studying!");
//		}
//		// Not operator exercise
//		System.out.println(true);
//		System.out.println(!true);
//		
//		boolean isDaytime = true;
//		System.out.println(!isDaytime);
		
//		// String inequality exercise
//		String var1 = new String("My dog Fido.");
//		String var2 = new String("My dog Spot.");	// different dog namel
//		
//		boolean equal12 = var1.equals(var2);
//		boolean notEqual12 = !var1.equals(var2);
//		System.out.println(equal12);
//		System.out.println(notEqual12);
		
//		// Hierarchy of Operators
//		boolean isSleepy = true;
//		boolean isLibraryClosed = true;
//		boolean isBatteryDead = false;
//		
//		if (isSleepy || isLibraryClosed && isBatteryDead) {
//			System.out.println("You should leave now.");
//		}
//		else {
//			System.out.println("Keep on studying!");
//		}
		
		// Less than (or equal to) operators
//		int a = 4;
//		int b = 4;
//		if (a <= b) {
//			System.out.println("a is less than or equal b");
//		}
//		else if (a > b) {
//			System.out.println("a is greater than b");
//		}
		
		// Greater than (or equal to) operators
		// declare the user's age in an integer variable
		
//		int userAge = 25;
//		
//		// if the user's age is at least 18 (greater than or equal to 18)
//		// then they can purchase tickets
//		
//		if (userAge >= 18) {
//			System.out.println("Here are your tickets, thank you and enjoy the show!");
//		}
//		// otherwise, they are under 18 and cannot purchase the tickets
//		else {
//			System.out.println("I'm sorry, you're too young for this movie.");
//		}
		
		// Arithmetic Operations
//		int sum = 2 + 2 + 1 + 5 + 8 + 4 +3;
//		sum++;
//		int difference = 5 - 2;
//		difference--;
//		System.out.println(sum);
//		System.out.println(difference);
//		
//		int product = 6 * 3;
//		int quotient = 6 / 1;
//		int remainder = 15468525 % 2452363;
//		System.out.println(product);
//		System.out.println(quotient);
//		System.out.println(remainder);
//		
//		// Hierarchy of operators
//		System.out.println(2 * 3 + 4);
//		System.out.println(2 + 3 * 4);
		
//		// declare an integer to hold the number
//		int number = 1245;
//		
//		/* if the modulus of the number (remainder) is divided by 2 is 0,
//		then it's even, otherwise it's odd */
//		int remainder = number % 2;
//		if (remainder == 1) {
//			System.out.println("The number is an odd number");
//		}
//		else {
//			System.out.println("The number is an even number");
//		}
		
		// String Manipulation
		// Concatenation
		String morningGreeting = "Good morning";
		String name = "Alex";
		System.out.println(morningGreeting);
		System.out.println(name);
		System.out.println(morningGreeting + " " + name);
		
		boolean isProgrammer = true;
		System.out.println("Am I a programmer? " + isProgrammer);
		
		int age = 36;
		System.out.println("My age: " + age);
		
		// Length
		int greetingLength = morningGreeting.length();
		System.out.println(greetingLength);
		
		// Lowercase & Uppercase
		System.out.println(morningGreeting.toUpperCase());
		System.out.println(morningGreeting.toLowerCase());
	}

}
