package com.AnthonyMack.helloworld;

public class HelloWorld {

	public static void main(String[] args) {
//		String message = "Hello World!";
//		System.out.println(message);
//		
//		String new_message = "he was taking a \"nap\" in the back of the class";
//	    System.out.println(new_message);
//	    
//	    char letter = 'E';
//	    System.out.println(letter);
//	    
//	    char new_letter = '\u03A9';
//	    System.out.println(new_letter);
//	    
//	    int age = 26;
//	    System.out.println(age);
//	    
//	    int sum = 2 + 2;
//	    int newSum = sum;
//
//	    System.out.println(sum);
//	    System.out.println(newSum);
//	    
//	    final int HOURS_IN_A_DAY = 24;
//	    System.out.println(HOURS_IN_A_DAY);
//	    
//	    boolean isCold = true;
//
//	    if (isCold) {
//	        System.out.println("Wear a coat. It's cold outside!");
//	    }
//	    
//	 // declare variables
//	    boolean isMarketOpen = true;
//
//	    // if the market is open, print "The market is open!"
//	    if (isMarketOpen) {
//	        System.out.println("The market is open!");
//	    }
//	    else {
//	        System.out.println("The market is closed.");
//		}
		
		// Looping until 'quit'
//		boolean isItTrue = true;
//		String userInput;
//		String killCode = "quit";
//		boolean check;
//
//		while (isItTrue) {
//			// my input: "Hi!"
//			userInput = StudentHelper.ReadInputString();
//			check = userInput.toLowerCase().equals(killCode);
//			if (check) {
//				// setting this variable to false will tell the loop to stop running
//				isItTrue = false;
//				System.out.println("Rest of the code...");
//			}
//			else {
//				System.out.println("Echo: " + userInput);
//			}
//		}
		
		// Infinite Loops
//		while (true) {
//			System.out.println("Forever!");
//		}
		
		// Do-While Loops
//		String userInput;
//		
//		do {
//			System.out.println("Computer: Hi");
//			// read user input
//			userInput = StudentHelper.ReadInputString();
//			// echo user input
//			System.out.println("You: " + userInput);
//		}
//		while (userInput.toLowerCase().equals("hi"));
//		
//		// illustrates the rest of the code
//		System.out.println("Out of the loop");
		
		
		// For Loops
		// Countdown demonstration with a while loop
		// start with counter variable with a value of 10
//		int count = 10;
//		
//		// while the counter value is greater than 0, print the value and substract 1
//		while (count > 0) {
//			System.out.println(count);
//			// decrease the count by subtracting one integer at a time
//			count--;
//		}
//		// once the loop is done, print "Lift Off!"
//		System.out.println("Lift Off!");
		
		// Countdown demonstration with a for loop
//		for (int count = 10; count > 0; count--) {
//			System.out.println(count);
//		}
//		System.out.println("Lift Off!");
		
		// Enhanced for loops
		String[] myArray = {"One", "Two", "Three"};
		for (int i = 0; i < myArray.length; i++) {
			System.out.println(myArray[i]);
		}
		
	}

}
