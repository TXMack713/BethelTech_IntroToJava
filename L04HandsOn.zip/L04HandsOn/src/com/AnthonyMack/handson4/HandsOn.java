package com.AnthonyMack.handson4;

public class HandsOn {

	public static void main(String[] args) {
		// 
		int number = 2;
		int times = 10;
		
		// Print the result of the doubleMe method
		System.out.println("Number: " + number);
		System.out.println("Doubled: " + (doubleMe(number)));
		
		// Print the result of the quadrupleMe method
		System.out.println("Number: " + number);
		System.out.println("Quadrupled: " + quadrupleMe(number));
		
		// Print the result of the doubleMeTimes method
		System.out.println("Number: " + number);
		System.out.println("Count: " + times);
		System.out.println("Result: " + doubleMeTimes(number, times));
		
	}
	
	public static int doubleMe(int value) {
		return value * 2;
	}
	
	public static int quadrupleMe(int num) {
		return doubleMe(num) * 2;
	}
	public static int doubleMeTimes(int value, int count) {
		int total = doubleMe(value);
		for (int i = 1; i < count; i++) {
			total *= 2;
		}
		return total;
	}

}
