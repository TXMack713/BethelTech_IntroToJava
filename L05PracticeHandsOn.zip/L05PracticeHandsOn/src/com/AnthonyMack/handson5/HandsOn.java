package com.AnthonyMack.handson5;

public class HandsOn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  class Person {
		        private String firstName;
		        private String lastName;
		        private int age;

		        public Person() {
		          firstName = "";
		          lastName = "";
		          age = 0;
		        }

		      // create a getter and a setter for the first name variable
		        public String getFirstName() {
		          return firstName;
		        }
		        public String setFirstName(String firstName) {
		          this.firstName = firstName;
		          return this.firstName;
		        }

		      // create a getter and a setter for the last name variable
		        public String getLastName() {
		          return lastName;
		        }
		        public String setLastName(String lastName) {
		          this.lastName = lastName;
		          return this.lastName;
		        }

		      // create a getter and a setter for the age variable
		        public int getAge() {
		          return age;
		        }
		        public int setAge(int age) {
		          if (age < 0) {
		            System.out.println("Attempted to set age to an invalid value. Setting age to 0 instead");
		            this.age = 0;
		          }
		          else {
		            this.age = age;
		          }
		          return this.age;
		        }

		      // create an overloaded constructor to handle entries with only a first name
		      public Person(String firstName) {
		        this.firstName = firstName;
		        lastName = "";
		        age = 0;
		      }

		      // create an overloaded constructor to handle entries with only a first and last name
		      public Person(String firstName, String lastName) {
		        this.firstName = firstName;
		        this.lastName = lastName;
		        age = 0;
		      }

		      // create an overloaded constructor to handle entries with all information provided
		      public Person(String firstName, String lastName, int age) {
		        this.firstName = firstName;
		        this.lastName = lastName;
		        if (age < 0) {
		            System.out.println("Attempted to set age to an invalid value. Setting age to 0 instead");
		            this.age = 0;
		          }
		          else {
		            this.age = age;
		          }
		      }
		  }
		  
		  Person user = new Person("Anthony", "Mack", 36);
		  String firstName = user.getFirstName();
		  String lastName = user.getLastName();
		  int age = user.getAge();
		  
		  System.out.println("Hi! Your name is " + firstName + " " + lastName + " and you are " + age + " years old.");
		  firstName = user.setFirstName("Lisa");
		  age = user.setAge(41);
		  System.out.println("Hi! Your name is " + firstName + " " + lastName + " and you are " + age + " years old.");


	}
}

