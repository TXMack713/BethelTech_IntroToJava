package com.AnthonyMack.lesson_3;

public class Lesson_3 {

	public static void main(String[] args) {
		// Collections and Loops
		
		// Example 1
		// individual variables for musician names
//		String musician1 = "John";
//		String musician2 = "George";
//		String musician3 = "Paul";
//		String musician4 = "Ringo";
		
//		String[] musicians = {"John", "George", "Paul", "Ringo"};
//		System.out.println(musicians[1]);
//		System.out.println(musicians.length);
//		
//		// Example 2
//		// declare a string array of student names
//		String[] students = {"Joshua Alexander", "Carol Thomas", "Marion Green", "Edward Johnson", "Katherine Jones", "Jared Williams"};
//		System.out.println(students[0]);
		
		// Example 3
		// specifying the size of the array first before assigning variables
		// when the size of an array is defined first, it doesn't change
//		String [] groceryList = new String[4];
//		groceryList[0] = "bread";
//		groceryList[1] = "eggs";
//		groceryList[2] = "milk";
//		groceryList[3] = "tea";
//		System.out.println(groceryList[1]);
//		
//		groceryList[1] = "beans";
//		System.out.println(groceryList[1]);
		
		// Example 4
		// create an array of the highest recorded temperatures in the state of Arizona
		// then print the first and last elements in the array
//		int[] highestArizonaTemperatures = {120, 122, 121, 118, 119};
//		System.out.println(highestArizonaTemperatures[0]);
//		System.out.println(highestArizonaTemperatures[4]);
//		// print out the third element in the array
//		System.out.println(highestArizonaTemperatures[2]);
		
		// Loops
		
		
	}

}
