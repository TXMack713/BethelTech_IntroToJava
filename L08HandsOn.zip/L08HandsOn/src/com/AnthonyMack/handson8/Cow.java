package com.AnthonyMack.handson8;

public class Cow implements Mammal {
	
	// constructor
	public Cow() {
		
	}
	
	public void speak() {
		System.out.println("Moo!");
	}
	
	public void run () {
		System.out.println("Cows can run at a top speed of 25 mph!");
	}
	
	public void eat() {
		System.out.println("Cows eat grass.");
	}
}
