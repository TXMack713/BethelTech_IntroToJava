package com.AnthonyMack.handson8;

public class Dog implements Mammal {
	
	// constructor
	public Dog() {
	
	}
	
	public void speak() {
		System.out.println("Bark!");
	}
	
	public void run() {
		System.out.println("Dogs can run at a top speed of 45 mph!");
	}
	
	public void eat() {
		System.out.println("Dogs eat bones");
	}

}
