package com.AnthonyMack.handson8;

public class HandsOn {

	public static void main(String[] args) {
		// Create instances of the Dog, Cat and Cow classes and call their methods
		Dog dog = new Dog();
		Cat cat = new Cat();
		Cow cow = new Cow();
		Turtle turtle = new Turtle();
		Lizard lizard = new Lizard();
		
		// call the speak and run methods of each mammal object
		dog.speak();
		dog.run();
		dog.eat();
		cat.speak();
		cat.run();
		cat.eat();
		cow.speak();
		cow.run();
		cow.eat();
		turtle.crawl();
		turtle.eat();
		lizard.crawl();
		lizard.eat();

	}

}
