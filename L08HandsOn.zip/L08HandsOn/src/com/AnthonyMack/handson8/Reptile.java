package com.AnthonyMack.handson8;

public interface Reptile extends Animal {
	void crawl();
}
