package com.AnthonyMack.handson8;

public class Cat implements Mammal {
	
	// constructor
	public Cat() {
		
	}
	
	public void speak() {
		System.out.println("Meow!");
	}
	
	public void run () {
		System.out.println("Cats can run at a top speed of 30 mph!");
	}
	
	public void eat() {
		System.out.println("Cats eat mice.");
	}
}
