package com.AnthonyMack.handson8;

public class Turtle implements Reptile {
	
	// constructor
	public Turtle() {
		
	}
	
	public void crawl() {
		System.out.println("Turtles can crawl at a speed of 0.25 mph for a short distance.");
	}
	
	public void eat() {
		System.out.println("Turtles eat lettuce.");
	}

}
