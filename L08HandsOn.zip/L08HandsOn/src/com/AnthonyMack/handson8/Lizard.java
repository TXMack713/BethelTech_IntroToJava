package com.AnthonyMack.handson8;

public class Lizard implements Reptile {
	
	// constructor
	public Lizard() {
		
	}

	public void crawl() {
		System.out.println("Lizards can crawl at a speed of 25 mph.");
	}
	
	public void eat() {
		System.out.println("Lizards eat crickets.");
	}

}
