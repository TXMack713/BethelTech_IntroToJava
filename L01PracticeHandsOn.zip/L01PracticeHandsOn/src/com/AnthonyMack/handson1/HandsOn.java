package com.AnthonyMack.handson1;

public class HandsOn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean isSunny = true;
		boolean atBeach = true;

		// If it's sunny, tell the user to "Wear sunglasses"
		// If they're at the beach, tell the user to wear sunblock
		
		if (isSunny) {
			System.out.println("It's sunny outside, please wear your sunglasses!");
			
			// if they're at the beach, tell them to wear sunblock
			if (atBeach) {
				System.out.println("Also, remember to wear sunblock!");
			}
			else {
				System.out.println("You don't need sunblock.");
			}
		}
		else {
			System.out.println("It's not sunny out, so you don't need to wear your sunglasses.");
			
			if (atBeach) {
				System.out.println("You should probably come back tomorrow.");
			}
			else {
				System.out.println("Don't go to the beach.");
			}
		}
	}

}
