package com.AnthonyMack.handson2;

public class HandsOn {

	public static void main(String[] args) {
		int age = 3;
		/* Senior citizen prices are $7 per ticket
		 * Minors 12 and under prices are $8 per ticket
		 * All other tickets are $10 each
		 */
		boolean isStudent = false;
		if (age >= 65) {
			System.out.println("That ticket is $7");
		}
		else if (age <= 12 && age >= 0) {
			System.out.println("That ticket is $8.");
		}
		else if (isStudent && age >= 0) {
			System.out.println("That ticket is $8.");
		}
		else if (age < 0) {
			System.out.println("I'm sorry that's an invalid age.");
		}
		else {
			System.out.println("That ticket is $10");
		}
	}

}
