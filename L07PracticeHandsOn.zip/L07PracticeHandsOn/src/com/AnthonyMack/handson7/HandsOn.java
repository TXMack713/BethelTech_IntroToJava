package com.AnthonyMack.handson7;

public class HandsOn {

	public static void main(String[] args) {
		// create instances of the Employee, Manager and Engineer classes and print out their details
		Employee employee = new Employee();
		employee.setFirstName("Anthony");
		employee.setLastName("Mack");
		employee.setCompanyName("Generac");
		employee.setYearsAtCompany(1);
		String employeeInfo = employee.toString();
		System.out.println(employeeInfo);
		
		Manager manager = new Manager("Scott", "McIntyre", "Weatherford", 15, "Product Champion");
		String managerInfo = manager.toString();
		System.out.println(managerInfo);
		
		Engineer engineer = new Engineer("Randy", "East", "GE Healthcare", 8, "Mechanical Systems Engineer");
		String engineerInfo = engineer.toString();
		System.out.println(engineerInfo);

	}

}
