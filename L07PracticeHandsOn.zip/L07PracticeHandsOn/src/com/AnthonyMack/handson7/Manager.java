package com.AnthonyMack.handson7;

public class Manager extends Employee {
	String jobTitle;
	
	public Manager() {
		super();
		jobTitle = "";
	}
	
	public Manager(String firstName, String lastName, String companyName, int yearsAtCompany, String jobTitle) {
		super(firstName, lastName, companyName, yearsAtCompany);
		this.jobTitle = jobTitle;
	}
	
	// method to get job title
	public String getJobTitle() {
		return this.jobTitle;
	}
	// method to set job title
	public void setJobTitle(String newJobTitle) {
		this.jobTitle = newJobTitle;
	}
	
	// override the Employee convert to string method
	@Override
	public String toString() {
		return this.firstName + " " + this.lastName + " has worked at " + this.companyName + " for " + this.yearsAtCompany + " year(s) as a(n) " + this.jobTitle + ".";
	}

}
