package com.AnthonyMack.handson7;

public class Employee {
	String firstName;
	String lastName;
	String companyName;
	int yearsAtCompany;
	
	public Employee() {
		firstName = "";
		lastName = "";
		companyName = "";
		yearsAtCompany = -1;
	}
	
	public Employee(String firstName, String lastName, String companyName, int yearsAtCompany) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.companyName = companyName;
		this.yearsAtCompany = yearsAtCompany;
	}
	// method to get first name
	public String getFirstName() {
		return firstName;
	}
	// method to set first name
	public void setFirstName(String newFirstName) {
		this.firstName = newFirstName;
	}
	// method to get last name
	public String getLastName() {
		return lastName;
	}
	// method to set last name
	public void setLastName(String newLastName) {
		this.lastName = newLastName;
	}
	// method to get company name
	public String getCompanyName() {
		return companyName;
	}
	// method to set company name
	public void setCompanyName(String newCompanyName) {
		this.companyName = newCompanyName;
	}
	// private method to get years at company
	private int getYearsAtCompany() {
		return yearsAtCompany;
	}
	// method to set years at company
	public void setYearsAtCompany(int newYearsAtCompany) {
		this.yearsAtCompany = newYearsAtCompany;
	}
	
	@Override
	public String toString() {
		return this.firstName + " " + this.lastName + " has worked at " + this.companyName + " for " + this.yearsAtCompany + " year(s).";
	}

	
	
	
}
