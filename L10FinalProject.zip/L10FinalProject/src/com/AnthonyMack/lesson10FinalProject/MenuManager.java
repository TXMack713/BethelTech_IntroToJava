package com.AnthonyMack.lesson10FinalProject;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.*;

@SuppressWarnings("unused")
public class MenuManager {
	// Create and initialize a task
	
	String task;
	boolean isComplete;

	// constructor
	public MenuManager() {
		task = "";
		isComplete = false;
	}
	
	// overloaded constructor
	public MenuManager(String task, boolean isComplete) {
		this.task = task;
		this.isComplete = isComplete;
	}
	// Create and initialize a task
//	static List<MenuManager> taskList = new ArrayList<MenuManager>();

	
	// method for adding a new task
	/* Adding a task
	 * ->Prompt user to enter the task
	 * ->Get task input with System.console().readLine()
	 * -> Upon pressing enter, a second prompt should 
	 * ask the user if the task is complete or not
	 * -> If task is complete, add (COMPLETE) to the end
	 * of the task.
	 * -> The task should be stored in its own variable
	 * -> Each task/complete object should be added to a list of objects
	 * -> Each task will be added by calling a method
	 */
	@SuppressWarnings("resource")
	public static MenuManager addTask() {
		MenuManager newTask = new MenuManager();
		System.out.println("Please enter the task details and press 'Enter/Return' when done:");
		Scanner scanTaskDetails = new Scanner(System.in);
		newTask.task = scanTaskDetails.nextLine();
		/*
		// String task = System.console().readLine(); // returns NullPointerException
		boolean isComplete;
		System.out.println("Is this task already complete? (yes/no)");
		Scanner scanIsComplete = new Scanner(System.in);
		String complete = scanIsComplete.nextLine();
		complete = complete.toLowerCase();
		// String complete = System.console().readLine(); // returns NullPointerException
		if (complete == "yes") {
			newTask.isComplete = true;
		}
		else if (complete == "no") {
			newTask.isComplete = false;
		}
		else {
			newTask.isComplete = false;
		}
		 MenuManager newTask = new MenuManager();
		 newTask.task = task;
		 newTask.isComplete = isComplete;
		 */
		return newTask;
	}
	
	// method for displaying the tasks
	/* List the Tasks
	 * -> Display all current tasks (indicate the completed task by displaying (COMPLETE)
	 * -> Tasks should be displayed 5 at a time with controls to navigate back a forward
	 * "b" for back, "f" for forward
	 */
	@SuppressWarnings("resource")
	public static void displayTasks() {
		// 1. Only display 5 items at a time
		// 2. to move forward, call moveForward() method
		// 3. to move backward, call moveBackward() method
		// 4. if isComplete == true, print (COMPLETE) along side task item
		
		String complete = "";
		for (int i = 0; i < TaskManager.taskList.size(); i++) {
			if (TaskManager.taskList.get(i).isComplete == true) {
			complete = "(COMPLETE)";
			}
			else {
				complete = "";
			}
			System.out.println((i + 1) + ". " + TaskManager.taskList.get(i).task  + " " + complete);
		}
//		static int i = 0;
//		static int p = 5;
//		if (TaskManager.taskList.size() > 5) {
//			do {
//				if (TaskManager.taskList.get(i).isComplete == true) {
//					complete = "(COMPLETE)";
//					}
//					else {
//						complete = "";
//					}
//				System.out.println((i + 1) + ". " + TaskManager.taskList.get(i).task  + " " + complete);
//				i++;
//			}while(i < p);
//
//			// Give the user the option to navigate back forth between the list pages
//			System.out.println("Displaying [" + (i-4) + "-" + (p) + " of " + TaskManager.taskList.size() + "] Enter b to go back, f to go forward");
//			Scanner scanNavigate = new Scanner(System.in);
//			String move = scanNavigate.nextLine();
//			move = move.toLowerCase();
//			// navigate forward
//			if (move == "f") {
//				i +=5;
//				p +=5;
//				if (p <= TaskManager.taskList.size()) {
//					do {
//						if (TaskManager.taskList.get(i).isComplete == true) {
//							complete = "(COMPLETE)";
//							}
//							else {
//								complete = "";
//							}
//						System.out.println((i + 1) + ". " + TaskManager.taskList.get(i).task  + " " + complete);
//						i++;
//					}while(i < p);
//				}
//				else {
//					do {
//						if (TaskManager.taskList.get(i).isComplete == true) {
//							complete = "(COMPLETE)";
//							}
//							else {
//								complete = "";
//							}
//						System.out.println((i + 1) + ". " + TaskManager.taskList.get(i).task  + " " + complete);
//						i++;
//					}while(i < TaskManager.taskList.size());
//				}
//			}
//			// navigate backward
//			if (move == "b") {
//				i -=5;
//				p -=5;
//				if (i <= 0) {
//					System.out.println("You are at the beginning of the task list.");
//				}
//				else {
//					do {
//						if (TaskManager.taskList.get(i).isComplete == true) {
//							complete = "(COMPLETE)";
//							}
//							else {
//								complete = "";
//							}
//						System.out.println((i + 1) + ". " + TaskManager.taskList.get(i).task  + " " + complete);
//						i++;
//					}while(i < p);
//				}
//			}
//		}
//		else {
//			for (int i = 0; i < TaskManager.taskList.size(); i++) {
//				if (TaskManager.taskList.get(i).isComplete == true) {
//				complete = "(COMPLETE)";
//				}
//				else {
//					complete = "";
//				}
//				System.out.println((i + 1) + ". " + TaskManager.taskList.get(i).task  + " " + complete);
//			}
//		}
			// System.out.println((i + 1) + ". " + TaskManager.taskList.get(i).task  + " " + complete);
	}
	
	
	// method for removing a task
	/* Removing a task
	 * -> First display all the tasks for the user in
	 * groups of 5
	 * -> Add controls to allow the user to view all the
	 * tasks, 5 at a time on screen
	 * -> Use "b" for back and "f" for forward
	 * -> The tasks display should indicate if a task is complete or not
	 * -> Prompt user for the task number they would like to remove
	 * -> Each task will be removed by calling a method
	 * -> Display the main menu again
	 */
	@SuppressWarnings("resource")
	public static void removeTask() {
		MenuManager.displayTasks();
		System.out.println("Please enter the number of the task you would like to remove and press Enter/Return:");
		Scanner scanUserTaskNumber = new Scanner(System.in);
		int taskNumber = scanUserTaskNumber.nextInt();
		if (taskNumber < 0 || taskNumber > TaskManager.taskList.size() ) {
			System.out.println("Invalid entry. Please select a number between 1 and " + (TaskManager.taskList.size()));
			Scanner scanUserReAttempt = new Scanner(System.in);
			taskNumber = scanUserReAttempt.nextInt();
		}
		else {
			TaskManager.taskList.remove(taskNumber-1);
		}
	}
	
	// method for marking a task complete
	/* Marking a task complete
	 * -> Create a list of all incomplete tasks
	 * -> Display the list (5 at a time) of all the incomplete tasks (with numbers)
	 * -> The user can enter the number of the task they want to mark complete
	 * -> Display the main menu again
	 */
	public static void markTaskComplete() {
		// create a new list specifically for all the incomplete tasks
		int displayNum = 0;
		List<MenuManager> incompleteTasks = new ArrayList<MenuManager>();

		// cycle through the taskList array for incomplete tasks and add them to the incompleteTasks array
		for (int i = 0; i < TaskManager.taskList.size(); i++) {
			if (TaskManager.taskList.get(i).isComplete == false) {
				System.out.println((displayNum + 1) + ". " + TaskManager.taskList.get(i).task);
				// incompleteTasks.get(displayNum).task = TaskManager.taskList.get(i).task;
				incompleteTasks.add(TaskManager.taskList.get(i));
				// incompleteTasks.get(displayNum).isComplete = TaskManager.taskList.get(i).isComplete;
				displayNum++;
			}
		}
		System.out.println("Which task would you like to mark complete?");
		@SuppressWarnings("resource")
		Scanner scanToMarkComplete = new Scanner(System.in);
		int taskNumber = scanToMarkComplete.nextInt();
		incompleteTasks.get(taskNumber-1).isComplete = true;
		
		/* cycle through the taskList array to find the matching case for the task that was marked complete
		 * and mark that task complete within the taskList array*/
		for (int i = 0; i < TaskManager.taskList.size(); i++) {
			if (incompleteTasks.get(taskNumber-1).task == TaskManager.taskList.get(i).task) {
				TaskManager.taskList.get(i).isComplete = true;
			}
		}
		
	}
	
}


