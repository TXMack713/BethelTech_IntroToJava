package com.AnthonyMack.lesson10FinalProject;

import java.util.ArrayList;
import java.util.List;
import java.util.*;

public class TaskManager {
	
		// Create and initialize a task
		static List<MenuManager> taskList = new ArrayList<MenuManager>();

	public static void main(String[] args) {
		/* Open initial screen with menu manager options
		 * 1. Add a task
		 * 2. Remove a task
		 * 3. Mark a task complete
		 * 4. List the tasks
		 * 
		 * Prompt: What would you like to do?
		 */
		//	 Create and initialize a task
//		List<MenuManager> taskList = new ArrayList<MenuManager>();
		displayMenu();

	}
	
	static void displayMenu() {
		
		System.out.println("Welcome to the Task Manager");
		System.out.println("Please select an option from the menu below.");
		System.out.println("1. Add a task");
		System.out.println("2. Remove a task");
		System.out.println("3. Mark a task complete");
		System.out.println("4. List the tasks");
		System.out.println("");
		System.out.println("Please enter the number of what would you like to do?");
		// String userInput = System.console().readLine();
		Scanner scan = new Scanner(System.in);
		String userInput = scan.nextLine();
		
		// Create and initialize a task
		// List<MenuManager> taskList = new ArrayList<MenuManager>();
		
		// Call a method based on the user's input
		switch (userInput) {
		case "1":
			// Call taskAdd() method
			TaskManager.taskList.add(MenuManager.addTask());
			displayMenu();
			break;
		case "2":
			// Call  taskRemove() method
			MenuManager.removeTask();
			displayMenu();
			break;
		case "3":
			// Call markTaskComplete() method
			MenuManager.markTaskComplete();
			displayMenu();
			break;
		case "4":
			// Call displayTasks() method
			MenuManager.displayTasks();
			break;
		default:
			System.out.println("Sorry, that is an invalid option.");
			displayMenu();
		}
	}

}
