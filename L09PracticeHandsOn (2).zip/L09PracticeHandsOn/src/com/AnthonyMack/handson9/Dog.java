package com.AnthonyMack.handson9;

public class Dog extends Animal {
	
	public Dog() {
		super(new Animal.AnimalBuilder("dog", 2, 2, 5));
	}

}
/* Solution from Bethel Tech
public class Dog extends Animal {
public Dog() {
    super(new Animal.AnimalBuilder("dog", 2, 2, 2));
}
}
*/