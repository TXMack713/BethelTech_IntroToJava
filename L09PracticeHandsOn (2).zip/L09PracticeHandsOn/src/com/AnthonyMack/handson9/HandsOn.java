package com.AnthonyMack.handson9;

import java.util.*;

public class HandsOn {

	public static void main(String[] args) {
		// define the animal factory
		AnimalFactory animalFactory = new AnimalFactory();
		
//		// produce a cat
//		Animal cat = animalFactory.getAnimal("cat");
//		System.out.println(cat.getName());
//		
//		// produce a dog
//		Animal dog = animalFactory.getAnimal("dog");
//		System.out.println(dog.getName());
//		
//		// produce a cow
//		Animal cow = animalFactory.getAnimal("cow");
//		System.out.println(cow.getName());
//		
//		// produce an unrecognized animal
//		Animal lion = animalFactory.getAnimal("lion");
		
		// create an ArrayList of Animal objects named animalList
		List<String> animalList = new ArrayList<String>();
		
		// create a loop to loop through all user entries until they signal to exit
		boolean keepLooping = true;
		String animalInput = "";
		int catCount = 0;
		int dogCount = 0;
		int cowCount = 0;
		
		do {
			animalInput = StudentHelper.ReadInputString();
			animalInput.toLowerCase();
			if (animalInput.equals("exit")) {
				keepLooping = false;
				for (int i = 0; i < animalList.size(); i++) {
					animalList.get(i);
					if (animalList.get(i) == "cat") {
						catCount++;
					}
					else if (animalList.get(i) == "dog") {
						dogCount++;
					}
					else if (animalList.get(i) == "cow") {
						cowCount++;
					}
				}
				System.out.println("Out of a total of " + animalList.size() + " entries, there are:");
				System.out.println(catCount + " cat(s)");
				System.out.println(dogCount + " dog(s)");
				System.out.println(cowCount + " cow(s)");
				System.out.println("There are also " + (animalList.size() - (catCount + dogCount + cowCount)) + " unrecognized animal(s)");
			}	
			else if (animalInput.equals("cat")) {
				Animal cat = animalFactory.getAnimal("cat");
				animalList.add("cat");
			}
			else if (animalInput.equals("dog")) {
				Animal dog = animalFactory.getAnimal("dog");
				animalList.add("dog");
			}
			else if (animalInput.equals("cow")) {
				Animal cow = animalFactory.getAnimal("cow");
				animalList.add("cow");
			}
			else {
				Animal notRecognized = animalFactory.getAnimal(animalInput);
			}
		}
		while(keepLooping);
		
		
		

	}

}
/* Solution from Bethel Tech
 * import java.util.ArrayList;
import java.util.List;

public class HandsOn {

    public static void main(String[] args) {
        List<Animal> animalList = new ArrayList<Animal>();
        AnimalFactory factory = new AnimalFactory();
        String animalType;

        // query input from user util `exit`
        do {
            System.out.print("Enter animal name or exit: ");
            animalType = StudentHelper.ReadInputString();
            if(!animalType.equalsIgnoreCase("exit")) {
                Animal animal = factory.getAnimal(animalType);
                if(animal != null) animalList.add(animal);
            }
        }
        while(!animalType.equalsIgnoreCase("exit"));

        // process results
        int numCats = 0, numDogs = 0, numCows = 0;
        for(Animal animal: animalList) {
            if(animal instanceof Cat) {
                numCats++;
            }
            else if(animal instanceof Dog) {
                numDogs++;
            }
            else if(animal instanceof Cow) {
                numCows++;
            }
        }
        System.out.println("RESULTS:");
        System.out.println("Num cats = " + numCats);
        System.out.println("Num dogs = " + numDogs);
        System.out.println("Num cows = " + numCows);
    }
}
*/
