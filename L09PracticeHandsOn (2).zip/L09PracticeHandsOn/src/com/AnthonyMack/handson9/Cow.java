package com.AnthonyMack.handson9;

public class Cow extends Animal {
	
	public Cow() {
		super(new Animal.AnimalBuilder("cow", 3, 3, 400));
	}

}
/* Solution from Bethel Tech
 * public class Cow extends Animal {
    public Cow() {
        super(new Animal.AnimalBuilder("cow", 3, 3, 3));
    }
}
 */