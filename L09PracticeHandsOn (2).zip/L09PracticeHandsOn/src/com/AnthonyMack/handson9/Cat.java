package com.AnthonyMack.handson9;

public class Cat extends Animal {
	
	public Cat() {
		super(new Animal.AnimalBuilder("cat", 1, 1, 3));
	}

}
/* Solution from Bethel Tech
 * public class Cat extends Animal {
    public Cat() {
        super(new Animal.AnimalBuilder("cat", 1, 1, 1));
    }
}
 */
