package com.AnthonyMack.handson3;

public class HandsOn {

	public static void main(String[] args) {
		// Step 1
		
		/* Define an integer array of size 5 with all elements
		 * initialized to the value of 0.
		 */
		int[] myArray = {0, 0, 0, 0, 0};
		
		/* Using a for loop and the ReadInputInt() static method of the
		 * StudentHelper class, read in (as input) the 5 integer values
		 * and store them into the array.
		 */
		for (int i = 0; i < myArray.length; i++) {
			System.out.println("Please enter the values of the array.");
			myArray[i] = StudentHelper.ReadInputInt();
		}
		
		/* Print the contents of the array to the console using a for loop
		 * to iterate over the elements of the array.
		 */
		for (int i = 0; i < myArray.length; i++) {
			System.out.println("The value at index " + i + " is " + myArray[i]);
		}
		
		// Step 2
		
		// Print the contents of the array in reverse order
		System.out.println("");
		for (int i = (myArray.length - 1); i >= 0; i--) {
			System.out.println("The value at index " + i + " is " + myArray[i]);
		}
		
		// Step 3
		
		// Print the values of the array where the index is odd
		System.out.println("");
		for (int i = 0; i < myArray.length; i++) {
			if (i%2 == 1) {
				System.out.println("The value at index " + i + " is " + myArray[i]);
			}
		}
	}

}
