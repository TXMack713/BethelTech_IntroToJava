package com.AnthonyMack.handson6;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;

public class HandsOn {

	public static void main(String[] args) throws Exception {
		// Step 1
		// Create a StringBuilder object to store the string of songs and separate the entries with commas
		// Array of songs
		String songs[] = {"Rock With You", "Smooth Criminal", "Wanna Be Startin' Something", "Thriller", "Beat It"};
		StringBuilder songList = new StringBuilder();
		for (int i = 0; i < songs.length; i++) {
			songList.append(songs[i]);
			// separate entries by appending a comma after each song entry
			songList.append(", ");
		}
		// verify that StringBuilder was populated properly
		 System.out.println(songList);
		
		// Step 2
		// create the BufferedWriter and BufferedReader variables to write to and read from the file
		BufferedWriter myWriter = new BufferedWriter(new FileWriter("songs.txt"));
		BufferedReader myReader = new BufferedReader(new FileReader("songs.txt"));
		String scannedFileContents = "";
		
		try {
			// open the file for writing
			myWriter.append(songList);
			// close the file
			myWriter.close();
		}
		catch (Exception e) {
			// print the stack trace (error)
			e.printStackTrace();
			System.out.println("Error when writing songs.txt");
		}
		finally {
			String inputStream;
			while ((inputStream = myReader.readLine()) != null) {
				scannedFileContents += inputStream;
			}
			// close the file when finished reading
			myReader.close();
			System.out.println(scannedFileContents);
		}
		

	}

}
